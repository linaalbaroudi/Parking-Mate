package DatabaseOperation;

import parking_mate.ParkingSpot;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import parking_mate.ParkingArea;

// A class for connecting to the parking spot table in the database.
public class ParkingSpotDB {

    Connection conn;
    PreparedStatement statement = null;
    ResultSet result = null;

    //Intialization of the database connection.
    public ParkingSpotDB() throws SQLException {
        conn = DatabaseConnection.DatabaseConnection();
    }
    
    //Inserting parking spots to the database.
    public void insertParkingSpot(ParkingSpot parkingspot, String ParkingAreaName) {
        try {
            //Connecting to parking area database queries handler class.
            ParkingAreaDB parkingAreaDB = new ParkingAreaDB();
            
            //Getting owner parking area ID by delegation to parking area database queries handler class.
            int id = parkingAreaDB.getParkingAreaId(ParkingAreaName);
            
            //Writing the query to insert the parking spot to the database.
            String insertParkingSpotQuery  = "insert into Parking_Spot('Spot_Number','Area','Availability','Price_per_hour') values('" + parkingspot.getSpotNumber() + "','" + id + "','" + parkingspot.isAvailability() + "','" + parkingspot.getPrice_per_hour() + "')";

            //Preparing data base query statement
            statement = conn.prepareStatement(insertParkingSpotQuery);
            
            //executuing data base query statement
            statement.execute();            

        }catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "Insert Query of parking spots Failed");
            
        } finally {
            //Closing database connection 
            flushStatementOnly();
            
        }
    }
    
    //Getting available parking spots in a particular parking area
    public ArrayList<ParkingSpot> getAvailableParkingSpots(ParkingArea parkingArea) throws SQLException {
        int parkingAreaNumber ;
        
        ParkingAreaDB parkingAreaDatabase = new ParkingAreaDB();
        parkingAreaNumber = parkingAreaDatabase.getParkingAreaId(parkingArea.getName());
        //Inirializing an array of available parking spots
        ArrayList<ParkingSpot> availableParkingSpots = new ArrayList<ParkingSpot>();
        
        try {
            //Writing the query to select from the available parking spots in the database.
            String selectParkingSpots = "select Spot_Number,Price_per_hour from Parking_Spot where Area = '" + parkingAreaNumber + "' AND Availability = 'true'";
            
            //Preparing data base query statement
            statement = conn.prepareStatement(selectParkingSpots);
            
            //executuing data base query statement
            result = statement.executeQuery();
            
            //getting results from the database and adding them to availableParkingSpots array.
            while (result.next()) {
                availableParkingSpots.add(new ParkingSpot(result.getInt("Spot_Number"), true, result.getInt("Price_per_hour")));
            }
            
        } catch (SQLException ex) {
           //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "select Query of parking spots Failed");
            
        } finally {
            //Closing database connection 
            flushStatementOnly();
        }
        //Returning the array of available parking sports in the specified parking area.
        return availableParkingSpots;
    }
    
    //Method to close database connection
    private void flushStatementOnly() {
        {
            try {
                //closing database connection statement
                statement.close();
            } catch (SQLException ex) {
                //throwing errors when closing the database
                System.err.print(ex.toString() + " >> CLOSING DB");
            }
        }
    }
}

 
