package DatabaseOperation;

import parking_mate.ParkingArea;
import parking_mate.ParkingSpot;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.ArrayList;

// class for connecting the parking area to its table
public class ParkingAreaDB {

    //Initializing database connection variables.
    Connection conn;
    PreparedStatement statement = null;
    ResultSet result = null;

    public ParkingAreaDB() throws SQLException {
        conn = DatabaseConnection.DatabaseConnection();
    }

    //method for getting nearby parking areas
    public ArrayList<ParkingArea> getNearbyParkingAreas(String location) {
        ArrayList<ParkingArea> nearbyParkingAreas = new ArrayList();
        try {
            String query = "select ID,name from Parking_Area where location = '" + location + "'";

            //execute database query
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();

            while (result.next()) {
                nearbyParkingAreas.add(new ParkingArea(result.getInt("ID"), location, result.getString("name")));
            }

        } catch (SQLException ex) {

            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n error coming from returning A booking DB Operation");
        }
        return nearbyParkingAreas;

    }

    // method for inserting a parking area
    public void insertParkingArea(ParkingArea parkingArea) {
        try {
            ParkingSpotDB parkingSpotDB = new ParkingSpotDB();
            String insertParkingArea = "insert into Parking_Area('name','Location') values('" + parkingArea.getName() + "','" + parkingArea.getLocation() + "')";
            List<ParkingSpot> parkingSpots = parkingArea.getParkingSpots();

            //insertParkingSpot
            statement = conn.prepareStatement(insertParkingArea);

            statement.execute();

            //JOptionPane.showMessageDialog(null, "successfully inserted a new insertParkingArea");
            for (int i = 0; i < parkingSpots.size(); i++) {
                parkingSpotDB.insertParkingSpot(parkingSpots.get(i), parkingArea.getName());
            }

        } catch (SQLException ex) {
            System.out.println(ex.toString() + "\n error coming from insert into parking areas");
        } finally {
            flushStatementOnly();
        }
    }

    // method for deleting parking area name
    public boolean deleteParkingAreaName(String ParkingName) {

        try {
            String deleteQuery = "delete from Parking_Area where name='" + ParkingName + "'";
            statement = conn.prepareStatement(deleteQuery);
            statement.execute();
            return true;

        } catch (SQLException ex) {
           System.out.println(ex.toString() + "\n error coming from deleting parking areas");
        } finally {
            flushStatementOnly();
        }
        return false;
    }

    //Method to close database connection
    private void flushStatementOnly() {
        {
            try {

                //closing database connection statement
                statement.close();
            } catch (SQLException ex) {
                //throwing errors when closing the database
                System.err.print(ex.toString() + " >> CLOSING DB");
            }
        }
    }

    // method for getting the public area id
    public int getParkingAreaId(String ParkingName) {
        int ParkingId = 0;
        try {
            String query = "select ID from Parking_Area where name = '" + ParkingName + "'";
            statement = conn.prepareStatement(query);
            result = statement.executeQuery();
            while (result.next()) {

                ParkingId = result.getInt("ID");
            }

        } catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n select id error from parking areas");
        }

        return ParkingId;
    }

}
