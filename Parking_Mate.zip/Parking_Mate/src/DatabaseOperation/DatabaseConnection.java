package DatabaseOperation;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author lina
 */
// Class for connecting to the database
public class DatabaseConnection {

    static Connection DatabaseConnection() {

        try {
            Class.forName("org.sqlite.JDBC");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:Parking_Mate_DB.db");
            return conn;
        } catch (Exception ex) {

            //Throwing exceptions of not being able to connect
            JOptionPane.showMessageDialog(null, ex.toString());
            return null;
        }
    }

}
