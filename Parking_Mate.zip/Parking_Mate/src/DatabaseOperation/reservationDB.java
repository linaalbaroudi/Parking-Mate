
package DatabaseOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import parking_mate.Reservation;

// A class for performaing queries to database reservation table.
public class reservationDB {

    //Initializing database connection variables.
    Connection conn;
    PreparedStatement statement = null;
    ResultSet result = null;
    
    //Intialization of the database connection.
    public reservationDB() throws SQLException {
        conn = DatabaseConnection.DatabaseConnection();
    }
    
    //Get the id of the member trying to reserve a parking spot.
    private int getMemberId(String memberName) {
        int memberId = 0;
        try {
            //database query statement
            String query = "select ID from Member where name = '" + memberName + "'";

            //Preparing data base query statement
            statement = conn.prepareStatement(query);

            //executuing data base query statement
            result = statement.executeQuery();

            //getting results from the database
            while (result.next()) {
                memberId = result.getInt("ID");
            }

        } catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "Select Query of get member Failed");
            
        } finally {
            //Closing database connection 
            flushStatementOnly();
        }

        //returning member's ID
        return memberId;
    }
    
    //Insert the parking spot reservation 
    public boolean insertReservation(Reservation reservation, String name) {
        try {
            //get the member's id to use it in accessing the database.
            int id = getMemberId(name);
            
            //Writing the queries to insert reservation and update sparking spot's availability
            String insertReservation = "insert into Reservations('Date','Time','Duration','Area','Spot','confirmation','Member','TotalCost') values('" + reservation.getDate() + "','" + reservation.getTime() + "','" + reservation.getDuration() + "','" + reservation.getParkingArea().getId() + "','" + reservation.getReservedSpot().getSpotNumber() + "','" + reservation.isConfirmed() + "','" + id + "','" + reservation.getTotalCost() + "')";
            String updateSpot = "update Parking_Spot set Availability = 'false' where Spot_Number='" + reservation.getReservedSpot().getSpotNumber() + "'";
            
            //Preparing data base query statement
            statement = conn.prepareStatement(insertReservation);
            //executuing data base query statement
            statement.execute();
            
            //Preparing data base query statement
            statement = conn.prepareStatement(updateSpot);
            //executuing data base query statement
            statement.execute();
            
            //return if inserted reservation successfully
            return true;

        } catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "Insert or update Query Failed");
            
        } finally {
            //Closing database connection 
            flushStatementOnly();
            
        }
        //return if inserted reservation wasn't completed successfully
        return false;
    }

    //Method to close database connection
    private void flushStatementOnly() {
        {
            try {
                //closing database connection statement
                statement.close();
            } catch (SQLException ex) {
                //throwing errors when closing the database
                System.err.print(ex.toString() + " >> CLOSING DB");
            }
        }
    }

}

 