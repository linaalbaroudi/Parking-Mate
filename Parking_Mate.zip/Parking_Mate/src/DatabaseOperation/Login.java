package DatabaseOperation;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import parking_mate.Member;

/* this calss has the following features:
-Creating Account
-Adding user to database
-logging in
 */
/**
 *
 * @author lina
 */
// Class for connecting the login feature to its table
public class Login extends JFrame {

    //Initializing database connection variables.
    Connection conn;
    PreparedStatement statement = null;
    ResultSet result = null;

    //throws SQLException
    public Login() throws SQLException {

        conn = DatabaseConnection.DatabaseConnection();

    }
    // method for creating an account 

    public static void createAccount() throws SQLException {

        Scanner input = new Scanner(System.in);

        // get the user's name as an input
        System.out.println("Create Account Interface\n Please enter your name:");
        String name = input.next();

        //making sure the name is valid 
        while (!isStringOnlyAlphabet(name)) {
            System.out.println("The name should be only of alphabets.. Try Again");
            name = input.next();
        }

        //get the user's password as an input
        System.out.println("Please enter your password: (should contain digits, small and capital letters)");
        String password = input.next();

        //making sure the password is valid
        while (!passIsValid(password)) {
            System.out.println("The name should contain digits, small and capital letters.. Try Again");
            password = input.next();
        }

        //get the user's email as an input
        System.out.println("Please enter your email: ");
        String email = input.next();

        //making sure the email is valid
        while (!emailIsValid(email)) {
            System.out.println("The email is invalid.. Try Again");
            email = input.next();
        }

        //get the user's phone number as an input
        System.out.println("Please enter your phone number: ");
        String phone = input.next();

        //making sure the phone number is valid 
        while (!isPhoneValid(phone)) {
            System.out.println("The phone number is invalid.. Try Again using this pattern {05* *** ****} ");
            phone = input.next();
        }

        // creating new login 
        Member user = new Member(name, password, email, phone);
        Login newLogin = new Login();
        //printing the account has successfully created
        if (newLogin.addUser(user)) {
            System.out.println("Successfully created! redirecting to Login interface");
            Login();
            //printing that something went wrong    
        } else {
            System.out.println("Something went wrong.. try again");
            createAccount();
        }

    }
    // method for adding user to the database

    public boolean addUser(Member member) throws SQLException {
        try {
            String hashedPass = hashMe(member.getPassword());
            String insertQuery = "insert into Member('Name','Password','Email','Phone')"
                    + " values('"
                    + member.getName() + "','"
                    + hashedPass + "','" + member.getEmail() + "','" + member.getPhone() + "')";

            //execute database query
            statement = conn.prepareStatement(insertQuery);
            statement.execute();

            return true;
        } catch (SQLException ex) {
            System.out.println(ex.toString() + "\n" + "InsertQuery Failed");
            return false;
        } finally {
            flushStatementOnly();
        }

    }
    
    // method to let the user login by entering the username and password
    public static String Login() throws SQLException {
        // geting the name of the user
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter your name: ");
        String name = input.next();
        System.out.println("Please enter your password: ");

        // getting the password of the user
        String password = input.next();
        Login newLogin = new Login();

        //checking if the user has successfully been verified
        if (newLogin.verifyUser(name, password)) {
            return name;
        } else {

            // printing thaat the user entered valid data
            System.out.println("Invalid name or password.. Try Again");
            Login();
        }
        return "";
    }

    // method to verify that the user is in the database
    public boolean verifyUser(String name, String password) throws SQLException {
        try {

            String hashedPass = (name.equals("admin")) ? password : hashMe(password);
            String sql = "select * from Member where Name='" + name + "'AND Password= '" + hashedPass + "'"
                    + "";

            //Preparing data base query statement
            statement = conn.prepareStatement(sql);

            //executing data base query statement
            result = statement.executeQuery();

            if (result.next()) {
                statement.close();
                result.close();
                return true;
            }
        } catch (SQLException ex) {

            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n error coming from returning all customer DB Operation");

            return false;
        }
        return false;
    }

    // check if the name has only alphabets
    private static boolean isStringOnlyAlphabet(String str) {
        return ((!str.equals(""))
                && (str != null)
                && (str.matches("^[a-zA-Z]*$")));
    }

    // check if the password is valid
    private static boolean passIsValid(String s) {
        String n = ".*[0-9].*";
        String a = ".*[A-Z].*";
        return s.matches(n) && s.matches(a);
    }

    // check if the email is valid
    private static boolean emailIsValid(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
                + "[a-zA-Z0-9_+&*-]+)*@"
                + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
                + "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        if (email == null) {
            return false;
        }
        return pat.matcher(email).matches();
    }

    // check if the phone is valid
    private static boolean isPhoneValid(String s) {

        Pattern p = Pattern.compile("(05)?[0-9]{8}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }

    // method for validating the password
    private String hashMe(String password) {

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1"); //could also be MD5, SHA-256 etc.
            md.reset();
            md.update(password.getBytes("UTF-8"));
            byte[] resultByte = md.digest();
            password = String.format("%01x", new java.math.BigInteger(1, resultByte));

        } catch (NoSuchAlgorithmException e) {
            //do something.
        } catch (UnsupportedEncodingException ex) {
            //do something
        }
        return password;
    }

    //Method for closing database connection
    private void flushStatementOnly() {
        {
            try {

                //closing database connection statement
                statement.close();
            } catch (SQLException ex) {

                //throwing errors when closing the database
                System.err.print(ex.toString() + " >> CLOSING DB");
            }
        }
    }

}
