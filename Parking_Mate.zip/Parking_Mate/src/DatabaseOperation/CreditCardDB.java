package DatabaseOperation;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.ArrayList;
import parking_mate.CreditCard;

/**
 *
 * @author lolos
 */
// A class for connecting the credit card to its table
public class CreditCardDB {

    //Initializing database connection variables.
    Connection conn;
    PreparedStatement statement = null;
    ResultSet result = null;

    public CreditCardDB() throws SQLException {
        conn = DatabaseConnection.DatabaseConnection();

    }

    //Get the id of the member trying to use or add their credit cards 
    public int getMemberId(String name) {
        int id = 0;
        try {
            //Preparing data base query statement
            String query = "select ID from Member where name = '" + name + "'";

            //Preparing data base query statement
            statement = conn.prepareStatement(query);

            //executuing data base query statement
            result = statement.executeQuery();

            //getting results from the database
            while (result.next()) {
                id = result.getInt("ID");
            }

        } catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "SelectQuery of insertReservation Failed");
        } finally {
            //Closing database connection
            flushStatementOnly();
        }
        //returning member's ID
        return id;
    }

    // method for adding credit cards to the database
    public boolean addCreditCard(CreditCard card, String name) throws SQLException {
        try {
            int id = getMemberId(name);
            String insertQuery = "insert into Credit_Card('Number','HoldersName','Expiary_Date','CVV','memberID')"
                    + " values('"
                    + card.getNumber() + "','"
                    + card.getName() + "','" + card.getExpiryDate() + "','" + card.getCvv() + "','" + id + "')";
            //execute database query
            statement = conn.prepareStatement(insertQuery);
            statement.execute();

            return true;
        } catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "Select Query Failed");
            return false;
        } finally {

            //Closing database connection
            flushStatementOnly();
        }

    }

    //method for getting the added credit card 
    public ArrayList<CreditCard> getAddedCreditCards(String name) throws SQLException {
        ArrayList<CreditCard> membersCreditCards = new ArrayList<CreditCard>();
        try {
            int id = getMemberId(name);
            String insertQuery = "select * from Credit_Card where memberID = '" + id + "'";
            //execute database query
            statement = conn.prepareStatement(insertQuery);
            result = statement.executeQuery();
            while (result.next()) {
                membersCreditCards.add(new CreditCard(result.getString("Number"), result.getString("HoldersName"), result.getString("Expiary_Date"), result.getInt("CVV")));
            }

        } catch (SQLException ex) {
            System.out.println(ex.toString() + "\n" + "InsertQuery Failed");

        } finally {
            //Closing database connection
            flushStatementOnly();
        }
        return membersCreditCards;
    }

    //Method to close database connection
    private void flushStatementOnly() {
        {
            try {
                //closing database connection statement
                statement.close();
                //conn.close();
            } catch (SQLException ex) {

                //throwing errors when closing the database
                System.err.print(ex.toString() + " >> CLOSING DB");
            }
        }
    }

}
