package DatabaseOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import parking_mate.Reservation;

// A class for performaing payment related queries to the database.
public class PaymentDB {
    //Initializing database connection variables.
    Connection conn;
    PreparedStatement statement = null;
    ResultSet result = null;
    
    //Intialization of the database connection.
    public PaymentDB() throws SQLException {
        conn = DatabaseConnection.DatabaseConnection();
    }

    //Get the id of the member trying to pay for reservations.
    public int getMemberId(String memberName) {
        int memberId = 0;
        try {
            //database query statement
            String query = "select ID from Member where name = '" + memberName + "'";

            //Preparing data base query statement
            statement = conn.prepareStatement(query);

            //executuing data base query statement
            result = statement.executeQuery();

            //getting results from the database
            while (result.next()) {
                memberId = result.getInt("ID");
            }

        } catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "Select Query of get member Failed");
        } finally {
            //Closing database connection 
            flushStatementOnly();
        }

        //returning member's ID
        return memberId;
    }
    
    //Getting member's unpaid reservations
    public ArrayList<Reservation> getUnpaidReservations(String memberName) {
        //Initializing inpaid reservations array list
        ArrayList<Reservation> unpaidReservations = new ArrayList();

        try {
            //get the member's id to use it in accessing the database.
            int id = getMemberId(memberName);
            //Writing query to select unpaid reservation information from the database.
            String query = "select ID,Date,Time,Duration,TotalCost from Reservations where member = '" + id + "' AND isPaid = 'false'";
            
            //Preparing data base query statement
            statement = conn.prepareStatement(query);
            
            //executuing data base query statement
            result = statement.executeQuery();
            
            //getting results from the database and adding them to the unpaid reservations array
            while (result.next()) {
                unpaidReservations.add(new Reservation(result.getInt("ID"), null, result.getString("Date"), result.getString("Time"), result.getInt("Duration"), "", null, null, result.getInt("TotalCost"), true));
            }

        } catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "Select Query of unpaid reservations Failed");
        }
        //returning unpaid reservations of the passed member
        return unpaidReservations;
    }
    
    //Paying method for paying upaid reservations
    public boolean pay(int reservationID) throws SQLException {
        try {
            //updating the reservation's payment status in the database to paid.
            String insertQuery = "update Reservations set isPaid = 'true' where ID ='" + reservationID + "'";
            
            //Preparing data base query statement
            statement = conn.prepareStatement(insertQuery);
            
            //executuing data base query statement
            statement.execute();
            
            //return that the payment was successful
            return true;
        } catch (SQLException ex) {
            //Throwing exceptions of not being able to execute the query.
            System.out.println(ex.toString() + "\n" + "Update Query of unpaid reservations Failed");
            //return that the payment was not successful
            return false;
            
        } finally {
            //Closing database connection 
            flushStatementOnly();
        }

    }

    //Method to close database connection
    private void flushStatementOnly() {
        {
            try {
                //closing database connection statement
                statement.close();
            } catch (SQLException ex) {
                //throwing errors when closing the database
                System.err.print(ex.toString() + " >> CLOSING DB");
            }
        }
    }

}
