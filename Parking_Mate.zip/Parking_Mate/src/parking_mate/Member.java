/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parking_mate;

import DatabaseOperation.CreditCardDB;
import DatabaseOperation.ParkingAreaDB;
import DatabaseOperation.ParkingSpotDB;
import DatabaseOperation.PaymentDB;
import DatabaseOperation.reservationDB;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static jdk.nashorn.internal.objects.NativeString.trim;

/**
 *
 * @author lina Albaroudi, Hala Murad, Albatool Qatrangi, Shahed Alkharsah,
 * Einas Alkharsah
 */
public class Member extends User {

    private List<Reservation> reservations;

    // constructor
    public Member(String name, String password, String email, String phone) {
        super(name, password, email, phone);
    }

    /*
    * enable a member to set a new credit card
    * return true if the credit card is added successfully and false if it did not
     */
    public boolean setCreditCard() throws SQLException {
        boolean isSetted = false;

        Scanner input = new Scanner(System.in);

        //ask for credit card number
        System.out.println("Please enter the credit card number: {**** **** **** ****}");
        String creditCardNumber = input.next();

        // validate the credit card input 
        while (!(creditCardNumber.length() == 16 && isNumeric(creditCardNumber))) {
            System.out.println("Credit card number is invalid.. please follow this pattern {**** **** **** ****}");
            creditCardNumber = input.next();
        }

        // ask for credit card holder's name
        System.out.println("Please enter the card holder's name: ");
        String cardHolderName = input.next();

        // validate credit card holder's name
        while (!isOnlyAlphabet(cardHolderName)) {
            System.out.println("Invalid input.. should be alphabets only");
            cardHolderName = input.next();
        }

        //ask for credit card expiary date
        System.out.println("Please enter the card's expiary date: {MM/YY} ");
        String enteredDate = input.next();

        // validate credit card expiary date input
        while (!isNumeric(enteredDate)) {
            System.out.println("Invalid input.. should be alphabets only");
            enteredDate = input.next();
        }

        // ask for credit card CVV
        System.out.println("Please enter the card's CVV: {***} ");
        String CVV = input.next();

        // valdate CVV
        while (!isNumeric(CVV) || CVV.length() > 3) {
            System.out.println("Invalid input.. follow this pattern {***}");
            CVV = input.next();
        }

        // save the credit card data to a credit card object
        CreditCard enteredCard = new CreditCard(creditCardNumber, cardHolderName, enteredDate, Integer.parseInt(CVV));
        CreditCardDB CC_Connection = new CreditCardDB();

        if (CC_Connection.addCreditCard(enteredCard, this.getName())) {
            System.out.println("Credit card added successfully! ");
            isSetted = true;
        } else {
            System.out.println("Credit card wasn't added successfully! try again later");
        }
        return isSetted;
    }

    /*
    *  enables a member to reserve a parking spot
    *  @return true if the reservation is successful and false if it is not 
     */
    public boolean makeReservation() throws SQLException {
        boolean isReserved = false;

        Scanner ReservationInput = new Scanner(System.in);

        // ask for reservation time 
        System.out.println("Enter desired time: {HH:MM}");
        String enteredTime = ReservationInput.next();

        // validate the time input
        while (!validateTime(enteredTime)) {
            System.out.println("Invalid time.. follow this format {HH:MM}");
            enteredTime = ReservationInput.next();
        }

        //ask for reservation date
        System.out.println("Enter desired date: {DD/MM/YYYY}");
        String date = ReservationInput.next();

        // validate the date input
        while (!validateDate(date)) {
            System.out.println("Invalid date.. follow this format{DD/MM/YYYY}");
            date = ReservationInput.next();
        }

        //ask for reservation duration
        System.out.println("Enter desired duration in hours: ");
        String duration = ReservationInput.next();

        // validate reservation duration input
        while (!isNumeric(duration)) {
            System.out.println("Invalid duration.. Enter duration in hours");
            duration = ReservationInput.next();
        }

        // Enter your location
        System.out.println("Enter your location: only available in Olaya and Rahmaniya ");
        String location = ReservationInput.next();

        /* 
        *  validate if the entered location is either Olaya or Rahmaniya
        *  other locations will be available in future releases
         */
        while (!"Olaya".equals(location) && !"Rahmaniya".equals(location)) {
            System.out.println("Invalid input..  only available in Olaya and Rahmaniya");
            location = ReservationInput.next();
        }

        // choose a parking area
        ParkingArea choosenParkingArea = chooseArea(location);

        // choose a parking spot 
        ParkingSpot chosenParkingSpot = chooseSpot(choosenParkingArea);
        
        //Display total cost
        int spotCost = chosenParkingSpot.getPrice_per_hour();
        int cost = totalCost(spotCost, duration);

        //Do you want to confirm reservation?
        boolean isConfirmed = confirmReservation();

        // create a reservation object to submit to the database
        Reservation reservation = new Reservation(this, date, enteredTime, Integer.parseInt(duration), location, choosenParkingArea, chosenParkingSpot, cost, isConfirmed);
        
        if(isConfirmed){
        reservationDB reservationDatabase = new reservationDB();
        reservationDatabase.insertReservation(reservation, this.getName());
        return true;
        }
        
       return false;

    }

    /*
    *  @return true if the passed string contains only numbers, and false if it doesn't
     */
    public static boolean isNumeric(String str) {
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    /*
    *  @return true if the date input is valid and false if the date input is not valid
    *  valid date input contains only 10 character inthe format (DD/MM/YYYY)
     */
    public static boolean validateDate(String date) {
        if(date.length() != 10){
        return false;
        }
        
        String day = date.substring(0, 2);
        String month = date.substring(3, 5);
        String year = date.substring(6);

        boolean isDigit = isNumeric(day) && isNumeric(month) && isNumeric(year);
        boolean containsSplashes = "/".charAt(0) == date.charAt(2) && "/".charAt(0) == date.charAt(5);
        boolean inValidDate = Integer.parseInt(day) <= 31 && Integer.parseInt(month) <= 12 && Integer.parseInt(year) >= 2020;

        //check if not numeric , doesn't contain splitting splashes, doesn't have a valid date components
        return isDigit && containsSplashes && inValidDate;
    }

    /*
    *  @return true if the time input is valid and false if the time input is not valid
    *  valid time input contains only 5 character inthe format (HH:MM)
     */
    private static boolean validateTime(String time) {
        if (time.length() != 5) {
            return false;
        }
        String hours = time.substring(0, 2);
        String minutes = time.substring(3);
        if (!isNumeric(hours) || !isNumeric(minutes) || ":".charAt(0) != time.charAt(2)) {
            return false;
        }
        if (Integer.parseInt(hours) > 24 || Integer.parseInt(minutes) > 60) {
            return false;
        }
        return true;
    }

    /*
    * @return a choosen parking area from a liat of nearby parking areas
     */
    private ParkingArea chooseArea(String location) throws SQLException {

        Scanner areaInput = new Scanner(System.in); // take input from user

        // display nearby Parking Areas to the user
        System.out.println("Nearby Parking Areas ");

        ParkingAreaDB parkingAreaDatabase = new ParkingAreaDB(); // to retreive the parking areas from the database

        // a list to strore nearby parking areas for dispaly and for reference
        ArrayList<ParkingArea> nearbyParkingAreas = (ArrayList<ParkingArea>) parkingAreaDatabase.getNearbyParkingAreas(location);
        ArrayList<Integer> AreasIds = new ArrayList<>();

        // add the parking area id to the list AreasIds
        for (int i = 0; i < nearbyParkingAreas.size(); i++) {
            System.out.println(nearbyParkingAreas.get(i).getName() + " with number : " + nearbyParkingAreas.get(i).getId());
            AreasIds.add(nearbyParkingAreas.get(i).getId());
        }

        // Ask user to choose parking area
        System.out.println("Choose a parking area number:");
        String parkingAreaNumber = areaInput.next();

        // validate the user input
        while (!(isNumeric(parkingAreaNumber) && AreasIds.contains(Integer.parseInt(parkingAreaNumber)))) {
            System.out.println("Invalid input.. choose from the numbers");
            parkingAreaNumber = areaInput.next();
        }

        //know which parking area
        ParkingArea chosenParkingArea = new ParkingArea(location, "");
        for (int i = 0; i < nearbyParkingAreas.size(); i++) {
            if (nearbyParkingAreas.get(i).getId() == Integer.parseInt(parkingAreaNumber)) {
                chosenParkingArea = nearbyParkingAreas.get(i);
                break;
            }
        }

        return chosenParkingArea;
    }

    /*
    * enable a member to choose a spot from an available spots in a parking area
    * @return a choosen parking spot 
     */
    ParkingSpot chooseSpot(ParkingArea parkingArea) throws SQLException {
        ParkingSpot chosenSpot = new ParkingSpot(0, true, 0);

        Scanner spotInput = new Scanner(System.in); // take input from user

        //Display available parking spots
        System.out.println("Avialable Parking Spots are: ");
        ParkingSpotDB parkingSpotDatabase = new ParkingSpotDB();

        // save available parking spots in a list
        ArrayList<Integer> availableSpotsID = new ArrayList<>();
        ArrayList<ParkingSpot> avaliableSpots = parkingSpotDatabase.getAvailableParkingSpots(parkingArea);

        // saave retreived spot numbers in the availableSpots list
        for (int i = 0; i < avaliableSpots.size(); i++) {
            System.out.println("Spot number: " + avaliableSpots.get(i).getSpotNumber());
            availableSpotsID.add(avaliableSpots.get(i).getSpotNumber());
        }

        // Ask member to choose a parking spot 
        System.out.println("Choose a parking spot number:");
        String spotNum = spotInput.next();

        // validating user input
        while (!(isNumeric(spotNum) && availableSpotsID.contains(Integer.parseInt(spotNum)))) {
            System.out.println("Invalid input.. choose from the numbers");
            spotNum = spotInput.next();
        }

        // know which parking spot
        for (int i = 0; i < avaliableSpots.size(); i++) {
            if (avaliableSpots.get(i).getSpotNumber() == Integer.parseInt(spotNum)) {
                chosenSpot = avaliableSpots.get(i);
                break;
            }
        }
        return chosenSpot;
    }

    /*
    * calculate the total cost of reserving a parking spot 
     */
    private int totalCost(int costPerHr, String duration) {
        int total = costPerHr * Integer.parseInt(duration);
        System.out.println("Total cost is: " + total);
        return total;
    }

    /*
    * @retutn true if the user confirms the reservation and false if not
     */
    private boolean confirmReservation() {
        boolean isConfirmed = false;

        Scanner confirmInput = new Scanner(System.in); // take input from user

        // Ask whether to confirm the reservation or not
        System.out.println("Do you want to confirm reservation?");
        String answer = trim(confirmInput.next().toLowerCase());

        while (!(answer.equals("yes") ^ answer.equals("no"))) {
            System.out.println("Invalid input.. answer with yes or no");
            answer = confirmInput.next();
        }
        isConfirmed = answer.equals("yes");
        return isConfirmed;
    }

    /*
    * enables a member to pay for a reservation
    * @return true if the payment is successful and false if it is not
     */
    public boolean pay() throws SQLException {
        // Ask the user to select from the displayed unpaid rservations to pay for
        System.out.println("Select which unpaid reservation to pay for.. choose by order number ");

        //Connection to payment database
        PaymentDB paymentDatabase = new PaymentDB();
        //get unpaid reservations from the database
        ArrayList<Reservation> unpaidReservations = paymentDatabase.getUnpaidReservations(this.getName());

        //leave payment interface if there are no unpaid reservations to pay for 
        if (unpaidReservations.isEmpty()) {
            System.out.println("No unpaid reservations exist! ");
            return false;
        }

        displayUnpaidReservations(unpaidReservations);

        //take unpaid reservation choice from the user
        Scanner input = new Scanner(System.in);
        String chosenUnpaidReservation = input.next();

        //validate the user's choice
        validateChoice(input, chosenUnpaidReservation, unpaidReservations.size());

        // Ask the user to select from the displayed credit cards to use for payment
        System.out.println("Select which credit card to use.. choose by order number ");

        //Connection to creditCard database
        CreditCardDB CreditCardDatabase = new CreditCardDB();
        //get addedCreditCards from the database
        ArrayList<CreditCard> addedCreditCards = CreditCardDatabase.getAddedCreditCards(this.getName());

        displayCreditCards(addedCreditCards);

        String chosenCreditCard = input.next();

        validateChoice(input, chosenCreditCard, addedCreditCards.size());

        System.out.println("Confirm payment of reservation with total cost = " + unpaidReservations.get(Integer.parseInt(chosenUnpaidReservation) - 1).getTotalCost() + " using card which ends with : " + addedCreditCards.get(Integer.parseInt(chosenCreditCard) - 1).getNumber().substring(12));

        String confirmation = input.next();

        //get Confirmation and complete payment changes in the database
        if (confirmPayment(input, confirmation)) {
            paymentDatabase.pay(unpaidReservations.get(Integer.parseInt(chosenUnpaidReservation) - 1).getId());
        }
        //return that payment was completed successfully
        return true;
    }

    private void displayUnpaidReservations(List<Reservation> unpaidReservations) {
        for (int i = 0; i < unpaidReservations.size(); i++) {
            System.out.println((i + 1) + "- Reservation at date " + unpaidReservations.get(i).getDate() + " at time " + unpaidReservations.get(i).getTime() + " for " + unpaidReservations.get(i).getDuration() + " hours with total cost " + unpaidReservations.get(i).getTotalCost());
        }
    }

    private void displayCreditCards(List<CreditCard> addedCreditCards) {
        for (int i = 0; i < addedCreditCards.size(); i++) {
            System.out.println((i + 1) + "- Credit card that's number is " + addedCreditCards.get(i).getNumber());
        }
    }

    private boolean confirmPayment(Scanner input, String confirmation) {
        while (!isYesOrNo(confirmation)) {
            System.out.println("Invalid input.. answer with yes or no");
            confirmation = input.next();
        }
        return ("yes".equals(trim(confirmation.toLowerCase())));
    }

    //validating user's list choices
    private void validateChoice(Scanner input, String choice, int range) {
        //keep validating input , proceed when valid
        boolean choiceWithinRanges = Integer.parseInt(choice) <= range && Integer.parseInt(choice) > 0;
        while (!isNumeric(choice) || !choiceWithinRanges) {
            System.out.println("Invalid choice..try to choose from the list");
            choice = input.next();
        }
    }

    /*
    * @return true if the answer is either yes or no and false if it is not
     */
    private boolean isYesOrNo(String answer) {
        boolean isValid = false;

        answer = trim(answer.toLowerCase());
        isValid = answer.equals("yes") ^ answer.equals("no");

        return isValid;
    }

    /*
    * @return true if the passed string contains only alphabits
     */
    public static boolean isOnlyAlphabet(String str) {
        return ((!str.equals(""))
                && (str != null)
                && (str.matches("^[a-zA-Z]*$")));
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

}
