/*
 * Admin can login and log out of the system,
 * add parking areas and spots and delete them
 */
package parking_mate;

import DatabaseOperation.ParkingAreaDB;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author lina Albaroudi, Hala Murad, Albatool Qatrangi, Shahed Alkharsah,
 * Einas Alkharsah
 */
public class Admin extends User {

    public Admin(String name, String password, String email, String phone) {
        super(name, password, email, phone);
    }

    // enables the admin to add a parking area to the database
    public void addParkingArea() throws SQLException {

        // initialize parking area object with a list of parking spots
        ParkingArea parkingArea = new ParkingArea("", "");
        ArrayList<ParkingSpot> parkingSpots = new ArrayList<>();

        // take the parking area details from the admin
        Scanner input = new Scanner(System.in);

        // ask for location of parking area
        System.out.println("Enter the location of the parking area: ");
        String location = input.nextLine();

        // validate the input from the user 
        while (!isStringOnlyAlphabet(location)) {
            System.out.println("Input should be only of alphabets ");
            location = input.nextLine();
        }

        // set the parking area location
        parkingArea.setLocation(location);

        //ask for name of parking area
        System.out.println("Enter the name of parking area: ");
        String name = input.nextLine();

        // set the name of the parking area
        parkingArea.setName(name);

        /*
        * ask for the detais of parking spots in a parking area
        * the detais are:
        * 1- the number of the parking spots in a parking area
        * 2- the availability of each parking spot
        * 3- the price of reserving the spot per hour
         */
        System.out.println("Enter the all spots at this parking area, when you are done write 'done' ");

        // initialize input variables for a parking spot 
        String userInput = "";
        boolean isAvailable = false;
        int parkingSpotNumber = 0;
        int cost = 0;

        // take admin input until he finishes
        while (!userInput.equals("done")) {

            System.out.println("Enter The number of the parking spot");
            parkingSpotNumber = input.nextInt();//TODO validation

            System.out.println("Is the parking spot available, write 't' if it is availble and 'f' if it is not avalible ");
            String isAvailableUserInput = input.next();

            // validate user input - todo***
            while (!isAvailableUserInput.equals("t") && !isAvailableUserInput.equals("f")) {
                System.out.println("Invalid input , enter 't' or 'f'");
                isAvailableUserInput = input.next();
            }
            if (isAvailableUserInput.equals("t")) {
                isAvailable = true;
            }

            System.out.println("Enter The price per hour ");
            cost = input.nextInt();//TODO validation

            // Add a new parking spot to the parking area
            parkingSpots.add(new ParkingSpot(parkingSpotNumber, isAvailable, cost));

            System.out.println("press anything if  there are other parking spots ? if No enter 'done' ");
            userInput = input.next();

        }

        // submit the data to the database 
        ParkingAreaDB parkingAreaDB = new ParkingAreaDB();
        parkingArea.setParkingSpots(parkingSpots);
        parkingAreaDB.insertParkingArea(parkingArea);
        System.out.println("Parking Area added!");

    }

    // enable admin to delete a parking area
    public boolean deleteParkingArea() throws SQLException {
        boolean isDeleted = false;

        // initialize the parking area name
        String parkingAreaName = "";

        // take admin input 
        System.out.println("Enter The name of parking Area that you want to delete");
        Scanner input = new Scanner(System.in);
        parkingAreaName = input.nextLine();

        // delete the parking area from the database
        ParkingAreaDB parkingAreaDB = new ParkingAreaDB();
        
        // notify the user if the deletion is successfull or not
        if (parkingAreaDB.deleteParkingAreaName(parkingAreaName)) {
            isDeleted = true;
            System.out.println("The parking area is deleted successfully");
        } else {
            isDeleted = false;
            System.out.println("No parking area with this name.. try again later!");
        }
        return isDeleted;

    }

    // validate user input contains string only
    private static boolean isStringOnlyAlphabet(String str) {
        return ((str != null)
                && (!str.equals(""))
                && (str.matches("^[a-zA-Z]*$")));
    }

}
