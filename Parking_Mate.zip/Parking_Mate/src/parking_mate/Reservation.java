/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parking_mate;

/**
 *
 *  @author lina Albaroudi, Hala Murad, Albatool Qatrangi, Shahed Alkharsah, Einas Alkharsah
 */
public class Reservation {
    private int id;
    private Member member;
    private String date;
    private String time;
    private int duration;
    private String userLocation; // in class diagram of type Location GPS وخرابيط
    private ParkingArea parkingArea;
    private ParkingSpot reservedSpot;
    private int totalCost;
    private boolean isConfirmed = false;
    private boolean isPaid=false;

    // constructor for inserting object to database
    public Reservation(Member member, String date, String time, int duration, String userLocation, ParkingArea parkingArea, ParkingSpot reservedSpot,int totalCost, boolean isConfirmed) {
        this.member = member;
        this.date = date;
        this.time = time;
        this.duration = duration;
        this.userLocation = userLocation;
        this.parkingArea = parkingArea;
        this.reservedSpot = reservedSpot;
       this.totalCost = totalCost;
       this.isConfirmed= isConfirmed;
    }
    
    // constructor for validation
    public Reservation(int id,Member member, String date, String time, int duration, String userLocation, ParkingArea parkingArea, ParkingSpot reservedSpot,int totalCost, boolean isConfirmed) {
        this.id = id;
        this.member = member;
        this.date = date;
        this.time = time;
        this.duration = duration;
        this.userLocation = userLocation;
        this.parkingArea = parkingArea;
        this.reservedSpot = reservedSpot;
       this.totalCost = totalCost;
       this.isConfirmed= isConfirmed;
    }

    // getters and setters 
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getUserLocation() {
        return userLocation;
    }

    public void setUserLocation(String userLocation) {
        this.userLocation = userLocation;
    }

    public ParkingArea getParkingArea() {
        return parkingArea;
    }

    public void setParkingArea(ParkingArea parkingArea) {
        this.parkingArea = parkingArea;
    }

    public ParkingSpot getReservedSpot() {
        return reservedSpot;
    }

    public void setReservedSpot(ParkingSpot reservedSpot) {
        this.reservedSpot = reservedSpot;
    }

    public int getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(int totalCost) {
        this.totalCost = totalCost;
    }

    public boolean isConfirmed() {
        return isConfirmed;
    }

    public void ConfirmeReservation(boolean isConfirmed) {
        this.isConfirmed = isConfirmed;
    }

    public boolean isIsPaid() {
        return isPaid;
    }

    public void setIsPaid(boolean isPaid) {
        this.isPaid = isPaid;
    }
    
    public String reservationSummary() {
        return "Reservation{" + "date=" + date + ", time=" + time + ", duration=" + duration + ", userLocation=" + userLocation + ", parkingArea=" + parkingArea + ", reservedSpot=" + reservedSpot + ", totalCost=" + totalCost + ", isConfirmed=" + isConfirmed + '}';
    }

}
