package parking_mate;

/**
 *
 * @author lina Albaroudi, Hala Murad, Albatool Qatrangi, Shahed Alkharsah,
 * Einas Alkharsah
 */
//A cless of credit card object
public class CreditCard {

    private final String number;// credit card number of pattern {**** **** **** ****}
    private final String holdersName;// credit card holder's name
    private final String expiryDate;// credit card expiry date of pattern{MMYY}
    private final int cvv;//Credit card CVV number of pattern {***}

    //constructor
    public CreditCard(String number, String holdersName, String expiryDate, int cvv) {
        this.number = number;
        this.holdersName = holdersName;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
    }

    //Attributes getters
    public String getNumber() {
        return number;
    }

    public String getName() {
        return holdersName;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public int getCvv() {
        return cvv;
    }

}
