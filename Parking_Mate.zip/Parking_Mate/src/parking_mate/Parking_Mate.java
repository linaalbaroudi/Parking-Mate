/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parking_mate;

import static DatabaseOperation.Login.createAccount;
import static DatabaseOperation.Login.Login;
import java.sql.SQLException;
import java.util.*;

/**
 * @author lina Albaroudi, Hala Murad, Albatool Qatrangi, Shahed Alkharsah,
 * Einas Alkharsah
 */
public class Parking_Mate {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {

        // displays the application start menu
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to Parking Mate System\nType 1 for signup and 2 for Login 0 for exit");
        String choice = input.next();

        //checking choice input is valid
        while (!choice.equals("1") && !choice.equals("2") && !choice.equals("0")) {
            System.out.println("Please enter either 1 or 2");
            choice = input.next();
        }

        /*
        *  initialzing the username of the user tying to log in
        *  example : hala
         */
        String name = "";
        switch (choice) {
            case "1":
                createAccount();
                break;
            case "2":
                name = Login();
                break;
            default:
                System.exit(0);
        }

        // check the user choice to execute a functionality
        if (name.equals("admin")) {
            System.out.println("Welcome Admin !\nSelect the number of the operation:\n1-Add Parking Area\n2-Delete Parking Area \npress 0 to logout and exit");

            Admin admin = new Admin("admin", "", "", "");
            String adminChoice = input.next();
            while (true) {
                switch (adminChoice) {
                    case "0":
                        admin.logout();
                        break;
                    case "1":
                        admin.addParkingArea();
                        break;
                    case "2":
                        admin.deleteParkingArea();
                        break;
                    case "5":
                        System.out.println("Welcome Admin !\nSelect the number of the operation:\n1-Add Parking Area\n2-Delete Parking Area \npress 0 to logout and exit");
                        break;
                    default:
                        System.out.println("Invalid input");
                }
                System.out.println("Enter an Integer value to run a function ! 5- to display options again");
                adminChoice = input.next();

            }
        } else {
            System.out.println("Welcome " + name + "\nSelect the number of the operation:\n1-Reserve Parking Spot\n2-Add Credit Card\n3-Pay for unpaid reservations\npress 0 to log out and exit");
            Member member = new Member(name, "", "", "");
            String memberChoice = input.next();
            while (true) {
                switch (memberChoice) {
                    case "0":
                        member.logout();
                        break;
                    case "1":
                        if (member.makeReservation()) {
                            System.out.println("Parking Spot reserved successfully! ");
                        } else {
                            System.out.println("Parking Spot wasn't reserved successfully! try again later");
                        }
                        break;
                    case "2":
                        member.setCreditCard();
                        break;
                    case "3":
                        if (member.pay()) {
                            System.out.println("Payment was completed successfully");
                        } else {
                            System.out.println("Payment wasn't completed successfully.. try again later");
                        }
                        break;
                    case "5":
                        System.out.println("Welcome " + name + "\nSelect the number of the operation:\n1-Reserve Parking Spot\n2-Add Credit Card\n3-Pay for unpaid reservations\npress 0 to log out and exit");
                        break;
                    default:
                        System.out.println("Invalid input");
                }
                System.out.println("Enter an Integer value to run a function ! 5- to display options again");
                memberChoice = input.next();

            }

        }

    }
}
