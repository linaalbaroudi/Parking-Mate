/*
 * Parking Area class is responsible for making new parking area objects that holds multiple parking spots
 */
package parking_mate;

import java.util.List;

/**
 *
 * @author lina Albaroudi, Hala Murad, Albatool Qatrangi, Shahed Alkharsah,
 * Einas Alkharsah
 */
public class ParkingArea {

    private int id; // unique ID for each parking area
    private String location; // name of neighborhood
    private String name; // name of  a facility
    private List<ParkingSpot> parkingSpots; // parking spots available in the parking area

    // constructor for adding parking areas to the database
    public ParkingArea(String location, String name) {
        this.location = location;
        this.name = name;
    }

    // constructor for validating parking areas 
    public ParkingArea(int id, String location, String name) {
        this.id = id;
        this.location = location;
        this.name = name;
    }

    /*
    * getters and setters
    */
    public int getId() {
        return id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ParkingSpot> getParkingSpots() {
        return parkingSpots;
    }

    public void setParkingSpots(List<ParkingSpot> parkingSpots) {
        this.parkingSpots = parkingSpots;
    }

    @Override
    public String toString() {
        return "ParkingArea{" + "location=" + location + ", name=" + name + ", parkingSpots=" + parkingSpots + '}';
    }
}
