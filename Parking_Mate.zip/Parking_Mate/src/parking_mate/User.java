/*
 * an abstract class that represents the users of the application
 * a user can be an admin or a member to tha application
 * a user can login, logout, 
 */
package parking_mate;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lina Albaroudi, Hala Murad, Albatool Qatrangi, Shahed Alkharsah,
 * Einas Alkharsah
 *
 */
public abstract class User {

    private String name;
    private String password;
    private String email;
    private String phone;

    public User(String name, String password, String email, String phone) {
        this.name = name;
        this.password = password;
        this.email = email;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * enable user login to the system using his username and password
     *
     * @return true if login has succeeded and false if not
     */
    public boolean login() {
        boolean isLoggedIn = false;

        // take user credintials input
        String enteredUserName;
        String enteredPassword;

        Scanner nameInput = new Scanner(System.in);
        System.out.println("Username:");
        enteredUserName = nameInput.next();

        Scanner passwordInput = new Scanner(System.in);
        System.out.println("Password:");
        enteredPassword = passwordInput.next();

        // check if user credintials matches
        if (enteredUserName.equals(this.getName()) && enteredPassword.equals(this.getPassword())) {
            isLoggedIn = true;
        }

        return isLoggedIn;
    }

    /**
     * enable user logout of the system
     * @return true if logout has succeeded and false if not
     */
    public boolean logout() {
        boolean isLoggedOut = false;
        try {
            System.out.println("Logging out!");
            System.exit(0);
            isLoggedOut = true;
        } catch (Throwable ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isLoggedOut;
    }

}
