package parking_mate;

/**
*
* @author lina Albaroudi, Hala Murad, Albatool Qatrangi, Shahed Alkharsah,
* Einas Alkharsah
*/
//A class for managing different parking spot opbjects
public class ParkingSpot {

    private final int spotNumber;// The parking spot number .
    private final boolean availability; // whether the spot is available for reservation or not.
    private final int price_per_hour;// the price of the parking spot per hour.

    // constructor
    public ParkingSpot(int spotNumber, boolean availability, int price_per_hour) {
        this.spotNumber = spotNumber;
        this.availability = availability;
        this.price_per_hour = price_per_hour;
    }

    //getters
    public int getPrice_per_hour() {
        return price_per_hour;
    }

    public int getSpotNumber() {
        return spotNumber;
    }

    public boolean isAvailability() {
        return availability;
    }
}

